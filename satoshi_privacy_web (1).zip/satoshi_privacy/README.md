# Satoshi Privacy

Primera versión de una web educativa para consultar metadatos públicos de transacciones Bitcoin.

## Funcionalidad
- Interfaz responsive en español, tema oscuro.
- Consulta TXID de 64 caracteres hexadecimales.
- Muestra confirmaciones, estado, fecha, bloque, número de entradas/salidas, valor total de salidas y tamaño.
- Enlace al explorador externo mempool.space.
- No solicita claves privadas, frases semilla ni acceso a un monedero.
- No recibe, mezcla ni transfiere fondos.

## Probar en tu ordenador
1. Descomprime el ZIP.
2. Abre `index.html` en un navegador actualizado.
3. Necesitas conexión a Internet para consultar la API pública de mempool.space.

Si el navegador bloquea solicitudes locales, inicia un servidor estático desde esta carpeta:
- Python: `python -m http.server 8000`
- Abre `http://localhost:8000`

## Publicar gratis con GitHub Pages
1. Crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio público llamado `satoshi-privacy`.
3. Sube `index.html` y `README.md` a la raíz del repositorio.
4. En el repositorio, abre **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**, elige `main` y `/ (root)`, y guarda.
6. GitHub mostrará la URL publicada en esa misma sección cuando termine el despliegue.

Alternativas de alojamiento estático: Netlify o Cloudflare Pages. No se requiere backend para esta demo.

## Dominio propio
Puedes comprar un dominio cuando decidas el nombre final. Después configúralo en la sección Pages del alojamiento y sigue las instrucciones DNS del proveedor. No hemos registrado ni comprobado la disponibilidad de ningún dominio.

## Privacidad y limitaciones
- El navegador realiza solicitudes a `https://mempool.space/api`. El proveedor puede ver la IP y el TXID consultado.
- La página no guarda TXID en un servidor propio, pero el historial del navegador o extensiones pueden conservar información.
- Para reducir la dependencia de terceros, considera operar tu propio nodo Bitcoin y una API compatible.
- El número de confirmaciones se calcula a partir de la altura de punta consultada; puede variar durante reorganizaciones de cadena.
- El total mostrado suma las salidas de la transacción; no equivale necesariamente al importe enviado a una sola persona.
- Esto no es una herramienta de análisis forense, no identifica personas y no garantiza anonimato.
- Antes de ofrecer un servicio público, revisa seguridad, accesibilidad, privacidad, términos del proveedor y obligaciones legales aplicables.
